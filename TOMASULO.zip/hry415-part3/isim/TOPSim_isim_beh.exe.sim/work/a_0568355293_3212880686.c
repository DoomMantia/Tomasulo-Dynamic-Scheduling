/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/amanesis/hry415-part3/RSSelectArithmetic.vhd";



static void work_a_0568355293_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    unsigned int t11;
    int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned char t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;

LAB0:    xsi_set_current_line(15, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB2;

LAB4:    xsi_set_current_line(19, ng0);
    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t1 = (t0 + 5140);
    t3 = 1;
    if (2U == 2U)
        goto LAB8;

LAB9:    t3 = 0;

LAB10:    if (t3 != 0)
        goto LAB5;

LAB7:    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t1 = (t0 + 5160);
    t3 = 1;
    if (2U == 2U)
        goto LAB23;

LAB24:    t3 = 0;

LAB25:    if (t3 != 0)
        goto LAB21;

LAB22:    xsi_set_current_line(46, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t12 = (2 - 2);
    t11 = (t12 * -1);
    t13 = (1U * t11);
    t14 = (0 + t13);
    t1 = (t2 + t14);
    t3 = *((unsigned char *)t1);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB36;

LAB38:    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t12 = (0 - 2);
    t11 = (t12 * -1);
    t13 = (1U * t11);
    t14 = (0 + t13);
    t1 = (t2 + t14);
    t3 = *((unsigned char *)t1);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB39;

LAB40:    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t12 = (1 - 2);
    t11 = (t12 * -1);
    t13 = (1U * t11);
    t14 = (0 + t13);
    t1 = (t2 + t14);
    t3 = *((unsigned char *)t1);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB41;

LAB42:    xsi_set_current_line(56, ng0);
    t1 = (t0 + 5195);
    t5 = (t0 + 3288);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 3U);
    xsi_driver_first_trans_fast_port(t5);

LAB37:
LAB6:
LAB3:    t1 = (t0 + 3144);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(16, ng0);
    t1 = (t0 + 5135);
    t6 = (t0 + 3224);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 2U);
    xsi_driver_first_trans_fast(t6);
    xsi_set_current_line(17, ng0);
    t1 = (t0 + 5137);
    t5 = (t0 + 3288);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 3U);
    xsi_driver_first_trans_fast_port(t5);
    goto LAB3;

LAB5:    xsi_set_current_line(20, ng0);
    t8 = (t0 + 1032U);
    t9 = *((char **)t8);
    t12 = (0 - 2);
    t13 = (t12 * -1);
    t14 = (1U * t13);
    t15 = (0 + t14);
    t8 = (t9 + t15);
    t4 = *((unsigned char *)t8);
    t16 = (t4 == (unsigned char)3);
    if (t16 != 0)
        goto LAB14;

LAB16:    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t12 = (1 - 2);
    t11 = (t12 * -1);
    t13 = (1U * t11);
    t14 = (0 + t13);
    t1 = (t2 + t14);
    t3 = *((unsigned char *)t1);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB17;

LAB18:    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t12 = (2 - 2);
    t11 = (t12 * -1);
    t13 = (1U * t11);
    t14 = (0 + t13);
    t1 = (t2 + t14);
    t3 = *((unsigned char *)t1);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB19;

LAB20:    xsi_set_current_line(30, ng0);
    t1 = (t0 + 5157);
    t5 = (t0 + 3288);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 3U);
    xsi_driver_first_trans_fast_port(t5);

LAB15:    goto LAB6;

LAB8:    t11 = 0;

LAB11:    if (t11 < 2U)
        goto LAB12;
    else
        goto LAB10;

LAB12:    t6 = (t2 + t11);
    t7 = (t1 + t11);
    if (*((unsigned char *)t6) != *((unsigned char *)t7))
        goto LAB9;

LAB13:    t11 = (t11 + 1);
    goto LAB11;

LAB14:    xsi_set_current_line(21, ng0);
    t10 = (t0 + 5142);
    t18 = (t0 + 3288);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    memcpy(t22, t10, 3U);
    xsi_driver_first_trans_fast_port(t18);
    xsi_set_current_line(22, ng0);
    t1 = (t0 + 5145);
    t5 = (t0 + 3224);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 2U);
    xsi_driver_first_trans_fast(t5);
    goto LAB15;

LAB17:    xsi_set_current_line(24, ng0);
    t5 = (t0 + 5147);
    t7 = (t0 + 3288);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t17 = *((char **)t10);
    memcpy(t17, t5, 3U);
    xsi_driver_first_trans_fast_port(t7);
    xsi_set_current_line(25, ng0);
    t1 = (t0 + 5150);
    t5 = (t0 + 3224);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 2U);
    xsi_driver_first_trans_fast(t5);
    goto LAB15;

LAB19:    xsi_set_current_line(27, ng0);
    t5 = (t0 + 5152);
    t7 = (t0 + 3288);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t17 = *((char **)t10);
    memcpy(t17, t5, 3U);
    xsi_driver_first_trans_fast_port(t7);
    xsi_set_current_line(28, ng0);
    t1 = (t0 + 5155);
    t5 = (t0 + 3224);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 2U);
    xsi_driver_first_trans_fast(t5);
    goto LAB15;

LAB21:    xsi_set_current_line(33, ng0);
    t8 = (t0 + 1032U);
    t9 = *((char **)t8);
    t12 = (1 - 2);
    t13 = (t12 * -1);
    t14 = (1U * t13);
    t15 = (0 + t14);
    t8 = (t9 + t15);
    t4 = *((unsigned char *)t8);
    t16 = (t4 == (unsigned char)3);
    if (t16 != 0)
        goto LAB29;

LAB31:    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t12 = (2 - 2);
    t11 = (t12 * -1);
    t13 = (1U * t11);
    t14 = (0 + t13);
    t1 = (t2 + t14);
    t3 = *((unsigned char *)t1);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB32;

LAB33:    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t12 = (0 - 2);
    t11 = (t12 * -1);
    t13 = (1U * t11);
    t14 = (0 + t13);
    t1 = (t2 + t14);
    t3 = *((unsigned char *)t1);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB34;

LAB35:    xsi_set_current_line(43, ng0);
    t1 = (t0 + 5177);
    t5 = (t0 + 3288);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 3U);
    xsi_driver_first_trans_fast_port(t5);

LAB30:    goto LAB6;

LAB23:    t11 = 0;

LAB26:    if (t11 < 2U)
        goto LAB27;
    else
        goto LAB25;

LAB27:    t6 = (t2 + t11);
    t7 = (t1 + t11);
    if (*((unsigned char *)t6) != *((unsigned char *)t7))
        goto LAB24;

LAB28:    t11 = (t11 + 1);
    goto LAB26;

LAB29:    xsi_set_current_line(34, ng0);
    t10 = (t0 + 5162);
    t18 = (t0 + 3288);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    memcpy(t22, t10, 3U);
    xsi_driver_first_trans_fast_port(t18);
    xsi_set_current_line(35, ng0);
    t1 = (t0 + 5165);
    t5 = (t0 + 3224);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 2U);
    xsi_driver_first_trans_fast(t5);
    goto LAB30;

LAB32:    xsi_set_current_line(37, ng0);
    t5 = (t0 + 5167);
    t7 = (t0 + 3288);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t17 = *((char **)t10);
    memcpy(t17, t5, 3U);
    xsi_driver_first_trans_fast_port(t7);
    xsi_set_current_line(38, ng0);
    t1 = (t0 + 5170);
    t5 = (t0 + 3224);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 2U);
    xsi_driver_first_trans_fast(t5);
    goto LAB30;

LAB34:    xsi_set_current_line(40, ng0);
    t5 = (t0 + 5172);
    t7 = (t0 + 3288);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t17 = *((char **)t10);
    memcpy(t17, t5, 3U);
    xsi_driver_first_trans_fast_port(t7);
    xsi_set_current_line(41, ng0);
    t1 = (t0 + 5175);
    t5 = (t0 + 3224);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 2U);
    xsi_driver_first_trans_fast(t5);
    goto LAB30;

LAB36:    xsi_set_current_line(47, ng0);
    t5 = (t0 + 5180);
    t7 = (t0 + 3288);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t17 = *((char **)t10);
    memcpy(t17, t5, 3U);
    xsi_driver_first_trans_fast_port(t7);
    xsi_set_current_line(48, ng0);
    t1 = (t0 + 5183);
    t5 = (t0 + 3224);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 2U);
    xsi_driver_first_trans_fast(t5);
    goto LAB37;

LAB39:    xsi_set_current_line(50, ng0);
    t5 = (t0 + 5185);
    t7 = (t0 + 3288);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t17 = *((char **)t10);
    memcpy(t17, t5, 3U);
    xsi_driver_first_trans_fast_port(t7);
    xsi_set_current_line(51, ng0);
    t1 = (t0 + 5188);
    t5 = (t0 + 3224);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 2U);
    xsi_driver_first_trans_fast(t5);
    goto LAB37;

LAB41:    xsi_set_current_line(53, ng0);
    t5 = (t0 + 5190);
    t7 = (t0 + 3288);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t17 = *((char **)t10);
    memcpy(t17, t5, 3U);
    xsi_driver_first_trans_fast_port(t7);
    xsi_set_current_line(54, ng0);
    t1 = (t0 + 5193);
    t5 = (t0 + 3224);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 2U);
    xsi_driver_first_trans_fast(t5);
    goto LAB37;

}


extern void work_a_0568355293_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0568355293_3212880686_p_0};
	xsi_register_didat("work_a_0568355293_3212880686", "isim/TOPSim_isim_beh.exe.sim/work/a_0568355293_3212880686.didat");
	xsi_register_executes(pe);
}
