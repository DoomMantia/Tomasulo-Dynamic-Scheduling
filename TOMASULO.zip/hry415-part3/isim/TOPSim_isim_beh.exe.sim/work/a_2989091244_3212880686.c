/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/amanesis/hry415-part3/Mux16x78.vhd";
extern char *IEEE_P_1242562249;

char *ieee_p_1242562249_sub_10420449594411817395_1035706684(char *, char *, int , int );


static void work_a_2989091244_3212880686_p_0(char *t0)
{
    char t4[16];
    char t6[16];
    char t11[16];
    char t16[16];
    char t21[16];
    char t26[16];
    char t31[16];
    char t36[16];
    char t41[16];
    char t46[16];
    char t51[16];
    char t56[16];
    char t61[16];
    char t66[16];
    char t71[16];
    char *t1;
    char *t2;
    char *t3;
    int t5;
    char *t7;
    char *t8;
    unsigned int t9;
    int t10;
    char *t12;
    char *t13;
    unsigned int t14;
    int t15;
    char *t17;
    char *t18;
    unsigned int t19;
    int t20;
    char *t22;
    char *t23;
    unsigned int t24;
    int t25;
    char *t27;
    char *t28;
    unsigned int t29;
    int t30;
    char *t32;
    char *t33;
    unsigned int t34;
    int t35;
    char *t37;
    char *t38;
    unsigned int t39;
    int t40;
    char *t42;
    char *t43;
    unsigned int t44;
    int t45;
    char *t47;
    char *t48;
    unsigned int t49;
    int t50;
    char *t52;
    char *t53;
    unsigned int t54;
    int t55;
    char *t57;
    char *t58;
    unsigned int t59;
    int t60;
    char *t62;
    char *t63;
    unsigned int t64;
    int t65;
    char *t67;
    char *t68;
    unsigned int t69;
    int t70;
    char *t72;
    char *t73;
    unsigned int t74;
    int t75;
    char *t76;
    char *t77;
    int t78;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    char *t82;
    char *t83;
    char *t84;
    char *t85;
    char *t86;

LAB0:    t1 = (t0 + 2504U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(14, ng0);
    t2 = (t0 + 1192U);
    t3 = *((char **)t2);
    t2 = ieee_p_1242562249_sub_10420449594411817395_1035706684(IEEE_P_1242562249, t4, 0, 4);
    t5 = xsi_mem_cmp(t2, t3, 4U);
    if (t5 == 1)
        goto LAB5;

LAB21:    t7 = ieee_p_1242562249_sub_10420449594411817395_1035706684(IEEE_P_1242562249, t6, 1, 4);
    t8 = (t6 + 12U);
    t9 = *((unsigned int *)t8);
    t9 = (t9 * 1U);
    t10 = xsi_mem_cmp(t7, t3, t9);
    if (t10 == 1)
        goto LAB6;

LAB22:    t12 = ieee_p_1242562249_sub_10420449594411817395_1035706684(IEEE_P_1242562249, t11, 2, 4);
    t13 = (t11 + 12U);
    t14 = *((unsigned int *)t13);
    t14 = (t14 * 1U);
    t15 = xsi_mem_cmp(t12, t3, t14);
    if (t15 == 1)
        goto LAB7;

LAB23:    t17 = ieee_p_1242562249_sub_10420449594411817395_1035706684(IEEE_P_1242562249, t16, 3, 4);
    t18 = (t16 + 12U);
    t19 = *((unsigned int *)t18);
    t19 = (t19 * 1U);
    t20 = xsi_mem_cmp(t17, t3, t19);
    if (t20 == 1)
        goto LAB8;

LAB24:    t22 = ieee_p_1242562249_sub_10420449594411817395_1035706684(IEEE_P_1242562249, t21, 4, 4);
    t23 = (t21 + 12U);
    t24 = *((unsigned int *)t23);
    t24 = (t24 * 1U);
    t25 = xsi_mem_cmp(t22, t3, t24);
    if (t25 == 1)
        goto LAB9;

LAB25:    t27 = ieee_p_1242562249_sub_10420449594411817395_1035706684(IEEE_P_1242562249, t26, 5, 4);
    t28 = (t26 + 12U);
    t29 = *((unsigned int *)t28);
    t29 = (t29 * 1U);
    t30 = xsi_mem_cmp(t27, t3, t29);
    if (t30 == 1)
        goto LAB10;

LAB26:    t32 = ieee_p_1242562249_sub_10420449594411817395_1035706684(IEEE_P_1242562249, t31, 6, 4);
    t33 = (t31 + 12U);
    t34 = *((unsigned int *)t33);
    t34 = (t34 * 1U);
    t35 = xsi_mem_cmp(t32, t3, t34);
    if (t35 == 1)
        goto LAB11;

LAB27:    t37 = ieee_p_1242562249_sub_10420449594411817395_1035706684(IEEE_P_1242562249, t36, 7, 4);
    t38 = (t36 + 12U);
    t39 = *((unsigned int *)t38);
    t39 = (t39 * 1U);
    t40 = xsi_mem_cmp(t37, t3, t39);
    if (t40 == 1)
        goto LAB12;

LAB28:    t42 = ieee_p_1242562249_sub_10420449594411817395_1035706684(IEEE_P_1242562249, t41, 8, 4);
    t43 = (t41 + 12U);
    t44 = *((unsigned int *)t43);
    t44 = (t44 * 1U);
    t45 = xsi_mem_cmp(t42, t3, t44);
    if (t45 == 1)
        goto LAB13;

LAB29:    t47 = ieee_p_1242562249_sub_10420449594411817395_1035706684(IEEE_P_1242562249, t46, 9, 4);
    t48 = (t46 + 12U);
    t49 = *((unsigned int *)t48);
    t49 = (t49 * 1U);
    t50 = xsi_mem_cmp(t47, t3, t49);
    if (t50 == 1)
        goto LAB14;

LAB30:    t52 = ieee_p_1242562249_sub_10420449594411817395_1035706684(IEEE_P_1242562249, t51, 10, 4);
    t53 = (t51 + 12U);
    t54 = *((unsigned int *)t53);
    t54 = (t54 * 1U);
    t55 = xsi_mem_cmp(t52, t3, t54);
    if (t55 == 1)
        goto LAB15;

LAB31:    t57 = ieee_p_1242562249_sub_10420449594411817395_1035706684(IEEE_P_1242562249, t56, 11, 4);
    t58 = (t56 + 12U);
    t59 = *((unsigned int *)t58);
    t59 = (t59 * 1U);
    t60 = xsi_mem_cmp(t57, t3, t59);
    if (t60 == 1)
        goto LAB16;

LAB32:    t62 = ieee_p_1242562249_sub_10420449594411817395_1035706684(IEEE_P_1242562249, t61, 12, 4);
    t63 = (t61 + 12U);
    t64 = *((unsigned int *)t63);
    t64 = (t64 * 1U);
    t65 = xsi_mem_cmp(t62, t3, t64);
    if (t65 == 1)
        goto LAB17;

LAB33:    t67 = ieee_p_1242562249_sub_10420449594411817395_1035706684(IEEE_P_1242562249, t66, 13, 4);
    t68 = (t66 + 12U);
    t69 = *((unsigned int *)t68);
    t69 = (t69 * 1U);
    t70 = xsi_mem_cmp(t67, t3, t69);
    if (t70 == 1)
        goto LAB18;

LAB34:    t72 = ieee_p_1242562249_sub_10420449594411817395_1035706684(IEEE_P_1242562249, t71, 14, 4);
    t73 = (t71 + 12U);
    t74 = *((unsigned int *)t73);
    t74 = (t74 * 1U);
    t75 = xsi_mem_cmp(t72, t3, t74);
    if (t75 == 1)
        goto LAB19;

LAB35:
LAB20:    xsi_set_current_line(15, ng0);
    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t5 = (15 - 15);
    t9 = (t5 * -1);
    t14 = (78U * t9);
    t19 = (0 + t14);
    t2 = (t3 + t19);
    t7 = (t0 + 2904);
    t8 = (t7 + 56U);
    t12 = *((char **)t8);
    t13 = (t12 + 56U);
    t17 = *((char **)t13);
    memcpy(t17, t2, 78U);
    xsi_driver_first_trans_fast_port(t7);

LAB4:    xsi_set_current_line(14, ng0);

LAB39:    t2 = (t0 + 2824);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB40;

LAB1:    return;
LAB5:    xsi_set_current_line(15, ng0);
    t76 = (t0 + 1032U);
    t77 = *((char **)t76);
    t78 = (0 - 15);
    t79 = (t78 * -1);
    t80 = (78U * t79);
    t81 = (0 + t80);
    t76 = (t77 + t81);
    t82 = (t0 + 2904);
    t83 = (t82 + 56U);
    t84 = *((char **)t83);
    t85 = (t84 + 56U);
    t86 = *((char **)t85);
    memcpy(t86, t76, 78U);
    xsi_driver_first_trans_fast_port(t82);
    goto LAB4;

LAB6:    xsi_set_current_line(15, ng0);
    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t5 = (1 - 15);
    t9 = (t5 * -1);
    t14 = (78U * t9);
    t19 = (0 + t14);
    t2 = (t3 + t19);
    t7 = (t0 + 2904);
    t8 = (t7 + 56U);
    t12 = *((char **)t8);
    t13 = (t12 + 56U);
    t17 = *((char **)t13);
    memcpy(t17, t2, 78U);
    xsi_driver_first_trans_fast_port(t7);
    goto LAB4;

LAB7:    xsi_set_current_line(15, ng0);
    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t5 = (2 - 15);
    t9 = (t5 * -1);
    t14 = (78U * t9);
    t19 = (0 + t14);
    t2 = (t3 + t19);
    t7 = (t0 + 2904);
    t8 = (t7 + 56U);
    t12 = *((char **)t8);
    t13 = (t12 + 56U);
    t17 = *((char **)t13);
    memcpy(t17, t2, 78U);
    xsi_driver_first_trans_fast_port(t7);
    goto LAB4;

LAB8:    xsi_set_current_line(15, ng0);
    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t5 = (3 - 15);
    t9 = (t5 * -1);
    t14 = (78U * t9);
    t19 = (0 + t14);
    t2 = (t3 + t19);
    t7 = (t0 + 2904);
    t8 = (t7 + 56U);
    t12 = *((char **)t8);
    t13 = (t12 + 56U);
    t17 = *((char **)t13);
    memcpy(t17, t2, 78U);
    xsi_driver_first_trans_fast_port(t7);
    goto LAB4;

LAB9:    xsi_set_current_line(15, ng0);
    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t5 = (4 - 15);
    t9 = (t5 * -1);
    t14 = (78U * t9);
    t19 = (0 + t14);
    t2 = (t3 + t19);
    t7 = (t0 + 2904);
    t8 = (t7 + 56U);
    t12 = *((char **)t8);
    t13 = (t12 + 56U);
    t17 = *((char **)t13);
    memcpy(t17, t2, 78U);
    xsi_driver_first_trans_fast_port(t7);
    goto LAB4;

LAB10:    xsi_set_current_line(15, ng0);
    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t5 = (5 - 15);
    t9 = (t5 * -1);
    t14 = (78U * t9);
    t19 = (0 + t14);
    t2 = (t3 + t19);
    t7 = (t0 + 2904);
    t8 = (t7 + 56U);
    t12 = *((char **)t8);
    t13 = (t12 + 56U);
    t17 = *((char **)t13);
    memcpy(t17, t2, 78U);
    xsi_driver_first_trans_fast_port(t7);
    goto LAB4;

LAB11:    xsi_set_current_line(15, ng0);
    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t5 = (6 - 15);
    t9 = (t5 * -1);
    t14 = (78U * t9);
    t19 = (0 + t14);
    t2 = (t3 + t19);
    t7 = (t0 + 2904);
    t8 = (t7 + 56U);
    t12 = *((char **)t8);
    t13 = (t12 + 56U);
    t17 = *((char **)t13);
    memcpy(t17, t2, 78U);
    xsi_driver_first_trans_fast_port(t7);
    goto LAB4;

LAB12:    xsi_set_current_line(15, ng0);
    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t5 = (7 - 15);
    t9 = (t5 * -1);
    t14 = (78U * t9);
    t19 = (0 + t14);
    t2 = (t3 + t19);
    t7 = (t0 + 2904);
    t8 = (t7 + 56U);
    t12 = *((char **)t8);
    t13 = (t12 + 56U);
    t17 = *((char **)t13);
    memcpy(t17, t2, 78U);
    xsi_driver_first_trans_fast_port(t7);
    goto LAB4;

LAB13:    xsi_set_current_line(15, ng0);
    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t5 = (8 - 15);
    t9 = (t5 * -1);
    t14 = (78U * t9);
    t19 = (0 + t14);
    t2 = (t3 + t19);
    t7 = (t0 + 2904);
    t8 = (t7 + 56U);
    t12 = *((char **)t8);
    t13 = (t12 + 56U);
    t17 = *((char **)t13);
    memcpy(t17, t2, 78U);
    xsi_driver_first_trans_fast_port(t7);
    goto LAB4;

LAB14:    xsi_set_current_line(15, ng0);
    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t5 = (9 - 15);
    t9 = (t5 * -1);
    t14 = (78U * t9);
    t19 = (0 + t14);
    t2 = (t3 + t19);
    t7 = (t0 + 2904);
    t8 = (t7 + 56U);
    t12 = *((char **)t8);
    t13 = (t12 + 56U);
    t17 = *((char **)t13);
    memcpy(t17, t2, 78U);
    xsi_driver_first_trans_fast_port(t7);
    goto LAB4;

LAB15:    xsi_set_current_line(15, ng0);
    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t5 = (10 - 15);
    t9 = (t5 * -1);
    t14 = (78U * t9);
    t19 = (0 + t14);
    t2 = (t3 + t19);
    t7 = (t0 + 2904);
    t8 = (t7 + 56U);
    t12 = *((char **)t8);
    t13 = (t12 + 56U);
    t17 = *((char **)t13);
    memcpy(t17, t2, 78U);
    xsi_driver_first_trans_fast_port(t7);
    goto LAB4;

LAB16:    xsi_set_current_line(15, ng0);
    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t5 = (11 - 15);
    t9 = (t5 * -1);
    t14 = (78U * t9);
    t19 = (0 + t14);
    t2 = (t3 + t19);
    t7 = (t0 + 2904);
    t8 = (t7 + 56U);
    t12 = *((char **)t8);
    t13 = (t12 + 56U);
    t17 = *((char **)t13);
    memcpy(t17, t2, 78U);
    xsi_driver_first_trans_fast_port(t7);
    goto LAB4;

LAB17:    xsi_set_current_line(15, ng0);
    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t5 = (12 - 15);
    t9 = (t5 * -1);
    t14 = (78U * t9);
    t19 = (0 + t14);
    t2 = (t3 + t19);
    t7 = (t0 + 2904);
    t8 = (t7 + 56U);
    t12 = *((char **)t8);
    t13 = (t12 + 56U);
    t17 = *((char **)t13);
    memcpy(t17, t2, 78U);
    xsi_driver_first_trans_fast_port(t7);
    goto LAB4;

LAB18:    xsi_set_current_line(15, ng0);
    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t5 = (13 - 15);
    t9 = (t5 * -1);
    t14 = (78U * t9);
    t19 = (0 + t14);
    t2 = (t3 + t19);
    t7 = (t0 + 2904);
    t8 = (t7 + 56U);
    t12 = *((char **)t8);
    t13 = (t12 + 56U);
    t17 = *((char **)t13);
    memcpy(t17, t2, 78U);
    xsi_driver_first_trans_fast_port(t7);
    goto LAB4;

LAB19:    xsi_set_current_line(15, ng0);
    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t5 = (14 - 15);
    t9 = (t5 * -1);
    t14 = (78U * t9);
    t19 = (0 + t14);
    t2 = (t3 + t19);
    t7 = (t0 + 2904);
    t8 = (t7 + 56U);
    t12 = *((char **)t8);
    t13 = (t12 + 56U);
    t17 = *((char **)t13);
    memcpy(t17, t2, 78U);
    xsi_driver_first_trans_fast_port(t7);
    goto LAB4;

LAB36:;
LAB37:    t3 = (t0 + 2824);
    *((int *)t3) = 0;
    goto LAB2;

LAB38:    goto LAB37;

LAB40:    goto LAB38;

}


extern void work_a_2989091244_3212880686_init()
{
	static char *pe[] = {(void *)work_a_2989091244_3212880686_p_0};
	xsi_register_didat("work_a_2989091244_3212880686", "isim/TOPSim_isim_beh.exe.sim/work/a_2989091244_3212880686.didat");
	xsi_register_executes(pe);
}
